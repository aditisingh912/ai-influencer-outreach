import pandas as pd
COLS=["name","username","profile_url","niche","followers","email","location","bio"]
def read_csv(file):
    df=pd.read_csv(file)
    for c in COLS:
        if c not in df.columns: df[c]=""
    df["username"]=df["username"].fillna("").astype(str).str.strip().str.lstrip("@").str.lower()
    df["followers"]=pd.to_numeric(df["followers"],errors="coerce").fillna(0).astype(int)
    df["email"]=df["email"].fillna("").astype(str).str.strip()
    return df[COLS].drop_duplicates("username")
def demos():
    return pd.DataFrame([
    ["Demo Creator One","demo_creator_one","https://www.instagram.com/demo_creator_one/","sustainable fashion",18000,"creator1@example.com","Delhi, India","Creates sustainable fashion styling content."],
    ["Demo Creator Two","demo_creator_two","https://www.instagram.com/demo_creator_two/","beauty",52000,"creator2@example.com","Noida, India","Beauty reviews and skincare routines."],
    ["Demo Creator Three","demo_creator_three","https://www.instagram.com/demo_creator_three/","technology",12000,"","Ghaziabad, India","Explains consumer technology and useful apps."]],columns=COLS)
