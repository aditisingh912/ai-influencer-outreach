import gspread
from google.oauth2.service_account import Credentials
from config import GOOGLE_SERVICE_ACCOUNT_FILE, GOOGLE_SHEET_ID
COLS=["username","name","profile_url","niche","followers","email","location","bio","ai_summary","score","category","status","last_contacted","followup_stage","opted_out"]
def sync(rows):
    if not GOOGLE_SHEET_ID: raise RuntimeError("Set GOOGLE_SHEET_ID in .env")
    creds=Credentials.from_service_account_file(GOOGLE_SERVICE_ACCOUNT_FILE,scopes=["https://www.googleapis.com/auth/spreadsheets"])
    ws=gspread.authorize(creds).open_by_key(GOOGLE_SHEET_ID).sheet1
    existing=ws.get_all_values()
    if not existing: ws.append_row(COLS); existing=[COLS]
    index={r[0]:i+1 for i,r in enumerate(existing[1:],start=1) if r}
    for p in rows:
        vals=[str(p.get(k,"")) for k in COLS]
        if p["username"] in index: ws.update(f"A{index[p['username']]}:O{index[p['username']]}",[vals])
        else: ws.append_row(vals)
